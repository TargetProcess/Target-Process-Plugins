namespace NBehave.Extended.BddStory
{
	public interface IBddGivenFragment
	{
		IBddWhenFragment When(string context);
		IBddGivenFragment And(string context);
	}
}