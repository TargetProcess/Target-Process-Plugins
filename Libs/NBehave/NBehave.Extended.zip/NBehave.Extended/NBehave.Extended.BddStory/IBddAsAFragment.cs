namespace NBehave.Extended.BddStory
{
	public interface IBddAsAFragment
	{
		IIWantFragment AsA(string role);
	}
}