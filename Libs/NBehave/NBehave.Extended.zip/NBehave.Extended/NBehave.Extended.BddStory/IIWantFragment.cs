namespace NBehave.Extended.BddStory
{
	public interface IIWantFragment
	{
		ISoThatFragment IWant(string feature);
	}
}