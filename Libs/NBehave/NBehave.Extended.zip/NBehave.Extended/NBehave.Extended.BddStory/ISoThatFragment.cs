namespace NBehave.Extended.BddStory
{
	public interface ISoThatFragment
	{
		BddStory SoThat(string benefit);
	}
}