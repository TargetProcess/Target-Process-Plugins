namespace NBehave.Extended.BddStory
{
	public interface IBddScenario
	{
		IBddGivenFragment Given(string context);
	}
}