namespace NBehave.Extended.BddStory
{
	public interface IBddWhenFragment
	{
		IBddThenFragment Then(string context);
		IBddWhenFragment And(string context);
	}
}