namespace NBehave.Extended.BddStory
{
	public interface IBddThenFragment
	{
		IBddThenFragment And(string context);
	}
}