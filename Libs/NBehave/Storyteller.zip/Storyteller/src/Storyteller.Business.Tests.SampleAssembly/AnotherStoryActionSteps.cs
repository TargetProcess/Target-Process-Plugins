﻿// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using NBehave.Narrator.Framework;

namespace Storyteller.Business.Tests.SampleAssembly
{
	[ActionSteps]
	public class AnotherStoryActionSteps
	{
		[Given("Another Given 0")]
		[Given("Another Given 1")]
		public void AnotherGivenActionStep()
		{
		}

		[When("Another When 0")]
		[When("Another When 1")]
		public void AnotherWhenActionStep()
		{
		}

		[Then("Another Then 0")]
		[Then("Another Then 1")]
		public void AnotherThenActionStep(string parameter)
		{
		}
	}
}