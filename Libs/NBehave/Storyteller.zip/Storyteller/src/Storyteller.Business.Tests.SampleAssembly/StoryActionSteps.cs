﻿// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using NBehave.Narrator.Framework;

namespace Storyteller.Business.Tests.SampleAssembly
{
	[ActionSteps]
	public class StoryActionSteps
	{
		[Given("Given 0")]
		[Given("Given 1")]
		public void GivenActionStep()
		{
		}

		[When("When 0")]
		[When("When 1")]
		public void WhenActionStep()
		{
		}

		[Then("Then 0")]
		[Then("Then 1")]
		public void ThenActionStep(string parameter)
		{
		}
	}
}