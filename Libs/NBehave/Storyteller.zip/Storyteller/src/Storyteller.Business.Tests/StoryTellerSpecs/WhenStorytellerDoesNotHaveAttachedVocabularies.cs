﻿// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using NUnit.Framework;
using Tp.Testing.Common.NBehave;

namespace Storyteller.Business.StoryTellerSpecs
{
	[TestFixture]
	public class WhenStorytellerDoesNotHaveAttachedVocabularies
	{
		[Test]
		public void ThenAllActionStepsAreRecognizedAsUnavailable()
		{
			const string storyTellerStory =
				@"Given a grey wolf in a wood
					When the red hat is walking by
					Then a grey wolf would catch her";

			var story =
				string.Format(
					@"Given Storyteller screen is clean
				And no action steps assembly loaded
				When an user starts to write such a story as: '{0}'
				Then action steps should be considered as PENDING: 'Given a grey wolf in a wood', 'When the red hat is walking by', 'Then a grey wolf would catch her'",
					storyTellerStory);

			story.Execute();
		}
	}
}