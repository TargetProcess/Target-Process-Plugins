﻿// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NUnit.Framework;
using Storyteller.Business.Tests.SampleAssembly;

namespace Storyteller.Business.StoryTellerSpecs
{
	[TestFixture]
	public class WhenStorytellerHasVocabularies
	{
		private Storyteller _storyteller;

		[SetUp]
		public void Init()
		{
			_storyteller = new Storyteller(Assembly.GetAssembly(typeof (StoryActionSteps)));
		}

		[Test]
		public void ShouldHaveActionSteps()
		{
			Assert.That(_storyteller.Count(), Is.EqualTo(1));
			var vocabulary = _storyteller.ToArray()[0];

			var noun = vocabulary.ToArray()[0];
			Assert.That(noun.Name, Is.EqualTo("Story Action Steps"));
			AreEqual(noun.SelectGiven, "Given 0", "Given 1");
			AreEqual(noun.SelectWhen, "When 0", "When 1");
			AreEqual(noun.SelectThen, "Then 0", "Then 1");

			noun = vocabulary.ToArray()[1];


			Assert.That(noun.Name, Is.EqualTo("Another Story Action Steps"));
			AreEqual(noun.SelectGiven, "Another Given 0", "Another Given 1");
			AreEqual(noun.SelectWhen, "Another When 0", "Another When 1");
			AreEqual(noun.SelectThen, "Another Then 0", "Another Then 1");
		}

		[Test]
		public void ShouldOutputItself()
		{
			var stringWriter = new StoryTellerRenderer();
			_storyteller.Accept(stringWriter);
			Assert.That(stringWriter.ToString(),
			            Is.EqualTo(
										@"/////////////////////////////////////////////////
Vocabulary assembly: Storyteller.Business.Tests.SampleAssembly

-------------------------------------------------
Story Action Steps

Given 0
Given 1
When 0
When 1
Then 0
Then 1
-------------------------------------------------
Another Story Action Steps

Another Given 0
Another Given 1
Another When 0
Another When 1
Another Then 0
Another Then 1
"));
		}

		private static void AreEqual(IEnumerable<INounAction> steps, params string[] expected)
		{
			Assert.That(steps.ToList().ConvertAll(x => x.ToString()), Is.EquivalentTo(expected));
		}
	}
}