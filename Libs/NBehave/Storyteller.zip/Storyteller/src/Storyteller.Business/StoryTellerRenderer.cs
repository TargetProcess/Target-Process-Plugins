﻿// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System.Linq;
using System.Text;

namespace Storyteller.Business
{
	public class StoryTellerRenderer : IStoryTellerVisitor
	{
		private readonly StringBuilder _stringBuilder;

		public StoryTellerRenderer()
		{
			_stringBuilder = new StringBuilder();
		}

		public override string ToString()
		{
			return _stringBuilder.ToString();
		}

		public void Visit(INounAction nounAction)
		{
			_stringBuilder.AppendLine(nounAction.ToString());
		}

		public void Visit(INoun noun)
		{
			_stringBuilder.AppendLine("-------------------------------------------------");
			_stringBuilder.AppendLine(noun.Name);
			_stringBuilder.AppendLine();

			noun.SelectGiven.ToList().ForEach(x => _stringBuilder.AppendLine(x.ToString()));
			noun.SelectWhen.ToList().ForEach(x => _stringBuilder.AppendLine(x.ToString()));
			noun.SelectThen.ToList().ForEach(x => _stringBuilder.AppendLine(x.ToString()));
		}

		public void Visit(IVocabulary vocabulary)
		{
			_stringBuilder.AppendLine("/////////////////////////////////////////////////");
			_stringBuilder.AppendLine(vocabulary.Name);
			_stringBuilder.AppendLine();
		}
	}
}