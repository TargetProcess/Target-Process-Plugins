// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System.Collections.Generic;
using System.Linq;

namespace Storyteller.Business
{
	public class Subject : IGlossary
	{
		private readonly IEnumerable<Noun> _vocabularies;

		public Subject(IEnumerable<Noun> vocabularies)
		{
			_vocabularies = vocabularies;
		}

		public int Count
		{
			get { return _vocabularies.ToArray().Length; }
		}

		public Noun this[int i]
		{
			get { return _vocabularies.ToArray()[i]; }
		}

		public void Accept(IStoryTellerVisitor visitor)
		{
			_vocabularies.ToList().ForEach(x => x.Accept(visitor));
		}
	}
}