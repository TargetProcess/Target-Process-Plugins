// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Storyteller.Business
{
	public class Storyteller : IEnumerable<IVocabulary>
	{
		private readonly List<IVocabulary> _vocabularies = new List<IVocabulary>();

		public Storyteller(params Assembly[] actionStepAssemblies)
		{
			actionStepAssemblies.ToList().ForEach(x => _vocabularies.Add(new Vocabulary(x)));
		}

		public void Accept(IStoryTellerVisitor visitor)
		{
			_vocabularies.ForEach(x => x.Accept(visitor));
		}

		public IEnumerator<IVocabulary> GetEnumerator()
		{
			return _vocabularies.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}
}