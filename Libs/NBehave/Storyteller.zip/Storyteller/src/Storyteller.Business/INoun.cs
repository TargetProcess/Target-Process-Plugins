// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System.Collections.Generic;

namespace Storyteller.Business
{
	public interface INoun : IEnumerable<INounAction>
	{
		string Name { get; }
		IEnumerable<INounAction> SelectWhen { get; }
		IEnumerable<INounAction> SelectGiven { get; }
		IEnumerable<INounAction> SelectThen { get; }
		void Accept(IStoryTellerVisitor visitor);
	}

}