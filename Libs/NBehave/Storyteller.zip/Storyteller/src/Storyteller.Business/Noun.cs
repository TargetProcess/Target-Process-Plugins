// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NBehave.Narrator.Framework;

namespace Storyteller.Business
{
	public class Noun : INoun
	{
		private readonly Type _actionStepsType;

		public Noun(Type actionStepsType)
		{
			_actionStepsType = actionStepsType;
		}

		public string Name
		{
			get
			{
				var result = string.Empty;
				foreach (var character in _actionStepsType.Name)
				{
					if (Char.IsUpper(character))
					{
						result += " ";
					}
					result += character;
				}
				return result.TrimEnd(' ').TrimStart(' ');
			}
		}

		public IEnumerable<INounAction> SelectWhen
		{
			get { return SelectActionSteps<WhenAttribute>(); }
		}

		public IEnumerable<INounAction> SelectGiven
		{
			get { return SelectActionSteps<GivenAttribute>(); }
		}

		public IEnumerable<INounAction> SelectThen
		{
			get { return SelectActionSteps<ThenAttribute>(); }
		}

		private IEnumerable<INounAction> SelectActionSteps<TActionStepAttribute>()
			where TActionStepAttribute : ActionStepAttribute
		{
			var methods = _actionStepsType.GetMethods(BindingFlags.Public | BindingFlags.Instance);
			var result = new List<INounAction>();
			foreach (var methodInfo in methods)
			{
				var attributes = methodInfo.GetCustomAttributes(true).OfType<TActionStepAttribute>().ToList();
				result.AddRange(attributes.ConvertAll(x => new NounAction(x, methodInfo)).OfType<INounAction>());
			}
			result.Sort((x, y) => x.ToString().CompareTo(y.ToString()));
			return result;
		}

		public void Accept(IStoryTellerVisitor visitor)
		{
			visitor.Visit(this);
		}

		public IEnumerator<INounAction> GetEnumerator()
		{
			var result = new List<INounAction>();
			result.AddRange(SelectGiven);
			result.AddRange(SelectWhen);
			result.AddRange(SelectThen);
			return result.GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}
	}
}