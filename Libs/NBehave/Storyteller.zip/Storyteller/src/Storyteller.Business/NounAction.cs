// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System.Reflection;
using NBehave.Narrator.Framework;

namespace Storyteller.Business
{
	public class NounAction : INounAction
	{
		private readonly ActionStepAttribute _actionStepAttribute;
		private readonly MethodInfo _methodInfo;

		public NounAction(ActionStepAttribute actionStepAttribute, MethodInfo methodInfo)
		{
			_actionStepAttribute = actionStepAttribute;
			_methodInfo = methodInfo;
		}

		public string MethodName
		{
			get { return _methodInfo.Name; }
		}

		public void Accept(IStoryTellerVisitor visitor)
		{
			visitor.Visit(this);
		}

		public override string ToString()
		{
			return _actionStepAttribute.ActionMatch.ToString().Replace(@"\s+", " ").Replace(@"\s*$", string.Empty);
		}
	}
}