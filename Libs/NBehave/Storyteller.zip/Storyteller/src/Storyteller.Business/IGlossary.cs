// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
namespace Storyteller.Business
{
	public interface IGlossary
	{
		int Count { get; }
		Noun this[int i] { get; }
		void Accept(IStoryTellerVisitor visitor);
	}
}