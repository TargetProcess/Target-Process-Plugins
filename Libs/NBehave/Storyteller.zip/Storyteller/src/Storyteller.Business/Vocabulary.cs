﻿// 
// Copyright (c) 2005-2009 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using NBehave.Narrator.Framework;

namespace Storyteller.Business
{
	internal class Vocabulary : IVocabulary
	{
		private readonly Assembly _assembly;

		public Vocabulary(Assembly assembly)
		{
			_assembly = assembly;
		}

		private List<INoun> GetNouns()
		{
			var actionStepClasses = from exportedType in _assembly.GetExportedTypes()
			                        where exportedType.IsDefined(typeof (ActionStepsAttribute), false)
			                        select exportedType;

			return actionStepClasses.ToList().ConvertAll(x => (INoun) new Noun(x));
		}

		public void Accept(IStoryTellerVisitor visitor)
		{
			visitor.Visit(this);
			this.ToList().ForEach(x => x.Accept(visitor));
		}

		public IEnumerator<INoun> GetEnumerator()
		{
			return GetNouns().GetEnumerator();
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		public string Name
		{
			get { return string.Format("Vocabulary assembly: {0}", _assembly.GetName().Name); }
		}
	}
}