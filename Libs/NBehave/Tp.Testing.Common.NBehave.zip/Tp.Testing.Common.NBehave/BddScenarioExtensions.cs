// 
// Copyright (c) 2005-2011 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using NBehave.Narrator.Framework;
using NBehave.Narrator.Framework.EventListeners;
using Tp.Testing.Common.NBehave.Cfg;

namespace Tp.Testing.Common.NBehave
{
	public static class BddScenarioExtensions
	{
		public static void Execute(this string scenario, params IEventListener[] eventListeners)
		{
			var stackTrace = new StackTrace();
			var type = stackTrace.GetFrame(1).GetMethod().DeclaringType;
			scenario.Execute(new StoryRunnerFilter(type.Namespace, type.Name, "."), new[] {type.Assembly}, eventListeners);
		}

		public static void Execute(this string scenario, StoryRunnerFilter filter, params Assembly[] assemblies)
		{
			Execute(scenario, filter, assemblies, new IEventListener[] {});
		}

		private static void Execute(this string scenario, StoryRunnerFilter filter, IEnumerable<Assembly> assemblies,
		                            params IEventListener[] eventListenersArg)
		{
			var eventListeners = new List<IEventListener>();
			eventListeners.AddRange(eventListenersArg);

			eventListeners.Add(new ColorfulConsoleOutputEventListener());
			eventListeners.Add(new FailSpecResultEventListener());

			var multiEventListener = new MultiOutputEventListener(eventListeners.ToArray());

			var builder = new TextScenarioRunner(multiEventListener, assemblies, filter);
			builder.Run(scenario);
		}

		public static void Execute(this string scenario, StoryRunnerFilter filter, params IEventListener[] eventListeners)
		{
			scenario.Execute(filter, GetActionStepAssemblies().ToArray());
		}

		public static void Execute(this string scenario, StoryRunnerFilter filter)
		{
			scenario.Execute(filter, GetActionStepAssemblies().ToArray());
		}

		private static IEnumerable<Assembly> GetActionStepAssemblies()
		{
			var section = ConfigurationManager.GetSection("nbehave") as NBehaveSection;
			if (section != null)
			{
				foreach (AssemblyElement assemblyElement in section.ActionStepAssemblies)
				{
					yield return Assembly.Load(assemblyElement.Name);
				}
			}
			else
			{
				foreach (var actionStepAssembly in from assembly in AppDomain.CurrentDomain.GetAssemblies()
				                                   where assembly.IsDefined(typeof (ActionStepsAssemblyAttribute), false)
				                                   select assembly)
				{
					yield return actionStepAssembly;
				}
			}
		}
	}
}