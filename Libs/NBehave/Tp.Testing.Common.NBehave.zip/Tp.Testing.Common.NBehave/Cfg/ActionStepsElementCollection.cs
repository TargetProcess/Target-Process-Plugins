﻿// 
// Copyright (c) 2005-2010 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System.Configuration;

namespace Tp.Testing.Common.NBehave.Cfg
{
	[ConfigurationCollection(typeof (AssemblyElement), CollectionType = ConfigurationElementCollectionType.BasicMap, AddItemName = "assembly")]
	public class ActionStepsElementCollection : ConfigurationElementCollection
	{
		protected override ConfigurationElement CreateNewElement()
		{
			return new AssemblyElement();
		}

		protected override object GetElementKey(ConfigurationElement element)
		{
			return ((AssemblyElement) element).Name;
		}
	}
}