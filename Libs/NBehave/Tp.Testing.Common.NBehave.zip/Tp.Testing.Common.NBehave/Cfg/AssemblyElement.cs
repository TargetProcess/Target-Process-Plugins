﻿// 
// Copyright (c) 2005-2010 TargetProcess. All rights reserved.
// TargetProcess proprietary/confidential. Use is subject to license terms. Redistribution of this file is strictly forbidden.
// 
using System.Configuration;

namespace Tp.Testing.Common.NBehave.Cfg
{
	public class AssemblyElement : ConfigurationElement
	{
		[ConfigurationProperty("name")]
		public string Name
		{
			get { return (string) this["name"]; }
			set { this["name"] = value; }
		}
	}
}